// [[Rcpp::depends(mnorm)]]
#include <RcppArmadillo.h>
#include <mnorm.h>
using namespace Rcpp;

// [[Rcpp::plugins(openmp)]]

//' 123
//' @description 123
//' @export
// [[Rcpp::export(rng = false)]]
double lnL_mnprobit(const arma::vec par,
                    const arma::vec z,
                    const arma::vec alt,
                    const arma::mat W,
                    const int n_cores = 1)
{
  // Multiple cores
  omp_set_num_threads(n_cores);
  
  // Get some dimensional data
  const int n_par = par.size();
  const int n_alt = alt.size();
  const int n_obs = z.size();
  const int n_coef = W.n_cols;
  const int n_coef_total = n_coef * (n_alt - 1);
  const int n_sigma = n_par - n_coef_total;
  
  // Determine indexes of coefficients and 
  // covariances in the vector of parameters
  arma::uvec coef_ind = arma::regspace<arma::uvec>(0, n_coef_total - 1);
  arma::uvec sigma_ind = arma::regspace<arma::uvec>(n_coef_total, n_par - 1);
  
  // Store the coefficients for each alternative
  arma::vec coef_vec = par.elem(coef_ind);
  arma::mat coef(n_coef, n_alt - 1);
  for (int i = 0; i < (n_alt - 1); i++) 
  {
    coef.col(i) = coef_vec.subvec(i * n_coef, (i + 1) * n_coef - 1);
  }
  
  // Construct the covariance matrix
  arma::vec sigma_vec = par.elem(sigma_ind);
  arma::mat sigma(n_alt - 1, n_alt - 1);
  sigma(0, 0) = 1;
  if (n_alt > 2)
  {
    int counter = 0;
    for (int i = 0; i < (n_alt - 1); i++)
    {
      for (int j = 0; j <= i; j++)
      {
        if (!((i == 0) & (j == 0)))
        {
          sigma.at(i, j) = sigma_vec.at(counter);
          sigma.at(j, i) = sigma.at(i, j);
          counter++;
        }
      }
    }
  }

  // Check that matrix is positive defined
  if(!sigma.is_sympd())
  {
    return(-(1e+100));
  }
  
  // Vector of zero means
  NumericVector mean_zero_R(n_alt - 1);
  
  // Estimate the linear index for each alternative
  arma::mat li(n_obs, n_alt - 1);
  for (int i = 0; i < (n_alt - 1); i++)
  {
    li.col(i) = W * coef.col(i);
  }

  // Vector to store log-likelihood information
  arma::vec lnL(n_obs);

  // Calculate log-likelihood dependentin on alternative
  for (int i = 0; i < n_alt; i++)
  {
    // Get indexes of observations related
    // to the alternative
    arma::uvec alt_ind = find(z == alt.at(i));
    int n_alt_obs = alt_ind.size();
    
    // Transformation matrix
    arma::mat transform_mat(n_alt, n_alt);
    transform_mat.diag().ones();
    
    transform_mat.diag().ones();
    if (i != (n_alt - 1))
    {
      transform_mat.col(i).ones();
      transform_mat.col(i) = -transform_mat.col(i);
    }
    transform_mat.shed_row(i);
    transform_mat.shed_col(n_alt - 1);
    
    // Construct covariance matrix for alternative
    arma::mat sigma_alt = transform_mat * sigma * transform_mat.t();
    NumericMatrix sigma_alt_R = wrap(sigma_alt);
    
    // Estimate all necessary differences in utilities
    // related to linear indexes
    arma::mat li_diff = arma::mat(n_alt_obs, n_alt - 1);
    if (i == (n_alt - 1))
    {
      li_diff = -li.rows(alt_ind);
    }
    else
    {
      arma::uvec i_uvec = {i};
      li_diff.col(n_alt - 2) = li.submat(alt_ind, i_uvec);
      for (int j = 0; j < (n_alt - 1); j++)
      {
        int counter = 0;
        arma::uvec j_uvec = {j};
        if (i != j)
        {
          li_diff.col(counter) = li.submat(alt_ind, i_uvec) - 
                                 li.submat(alt_ind, j_uvec);
          counter++;
        }
      }
    }
    NumericMatrix li_diff_R = wrap(li_diff);
    
    // Matrix of negative infinite values
    NumericMatrix lower_neg_inf(n_alt_obs, n_alt - 1);
    std::fill(lower_neg_inf.begin(), lower_neg_inf.end(), R_NegInf);
    
    // Calculate probabilities
    List prob_list = mnorm::pmnorm(lower_neg_inf, li_diff_R,
                                   NumericVector(), 
                                   mean_zero_R, sigma_alt_R,
                                   NumericVector(),
                                   1000, "default", true,
                                   false, false, false, false,
                                   false, R_NilValue, 1);
    arma::vec prob_tmp = prob_list["prob"];
    lnL.elem(alt_ind) = prob_tmp;
  }

  return(sum(lnL));
}
