#' @param grad_x logical; if \code{TRUE} then the vector of partial derivatives
#' of the density function will be calculated respect to each
#' element of \code{x}. If \code{x} is a matrix then gradients will be
#' estimated for each row of \code{x}.
