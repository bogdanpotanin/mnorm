#' @examples
#' # Consider multivariate normal vector:
#' # X = (X1, X2, X3, X4, X5) ~ N(mean, sigma)
#' 
#' # Prepare multivariate normal vector parameters
#'   # expected value
#' mean <- c(-2, -1, 0, 1, 2)
#' n_dim <- length(mean)
#'   # correlation matrix
#' cor <- c(   1,  0.1,  0.2,   0.3,  0.4,
#'           0.1,    1, -0.1,  -0.2, -0.3,
#'           0.2, -0.1,    1,   0.3,  0.2,
#'           0.3, -0.2,  0.3,     1, -0.05,
#'           0.4, -0.3,  0.2, -0.05,     1)
#' cor <- matrix(cor, ncol = n_dim, nrow = n_dim, byrow = TRUE)
#'   # covariance matrix
#' sd_mat <- diag(c(1, 1.5, 2, 2.5, 3))
#' sigma <- sd_mat %*% cor %*% t(sd_mat)
#' 
#' # Estimate the density of X at point (-1, 0, 1, 2, 3)
#' x <- c(-1, 0, 1, 2, 3)
#' d.list <- dmnorm(x = x, mean = mean, sigma = sigma)
#' d <- d.list$den
#' print(d)
#' 
#' # Estimate the density of X at points
#' # x=(-1, 0, 1, 2, 3) and y=(-1.2, -1.5, 0, 1.2, 1.5)
#' y <- c(-1.5, -1.2, 0, 1.2, 1.5)
#' xy <- rbind(x, y)
#' d.list.1 <- dmnorm(x = xy, mean = mean, sigma = sigma)
#' d.1 <- d.list.1$den
#' print(d.1)
#'
#' # Estimate the density of Xc=(X2, X4, X5 | X1 = -1, X3 = 1) at 
#' # point xd=(0, 2, 3) given conditioning values xg=(-1, 1)
#' given_ind <- c(1, 3)
#' d.list.2 <- dmnorm(x = x, mean = mean, sigma = sigma, 
#'                    given_ind = given_ind)
#' d.2 <- d.list.2$den
#' print(d.2)
#' 
#' # Estimate the gradient of X respect to the argument and 
#' # covariance matrix at points 'x' and 'y'
#' d.list.3 <- dmnorm(x = xy, mean = mean, sigma = sigma,
#'                    grad_x = TRUE, grad_sigma = TRUE)
#' # Gradient respect to the argument
#' grad_x.3 <- d.list.3$grad_x
#'    # at point 'x'
#' print(grad_x.3[1, ])
#'    # at point 'y'
#' print(grad_x.3[2, ])
#' # Partial derivative at point 'y' respect 
#' # to the 3-rd argument
#' print(grad_x.3[2, 3])
#' # Gradient respect to the covariance matrix
#' grad_sigma.3 <- d.list.3$grad_sigma
#' # Partial derivative respect to sigma(3, 5) at 
#' # point 'y'
#' print(grad_sigma.3[3, 5, 2])
#' 
#' # Estimate the gradient of the log-density function of 
#' # Xc=(X2, X4, X5 | X1 = -1, X3 = 1) and Yc=(X2, X4, X5 | X1 = -1.5, X3 = 0)
#' # respect to the argument and covariance matrix at 
#' # points xd=(0, 2, 3) and yd=(-1.2, 0, 1.5) respectively given
#' # conditioning values xg=(-1, 1) and yg=(-1.5, 0) correspondingly
#' d.list.4 <- dmnorm(x = xy, mean = mean, sigma = sigma,
#'                    grad_x = TRUE, grad_sigma = TRUE,
#'                    given_ind = given_ind, log = TRUE)
#' # Gradient respect to the argument
#' grad_x.4 <- d.list.4$grad_x
#'    # at point 'xd'
#' print(grad_x.4[1, ])
#'    # at point 'yd'
#' print(grad_x.4[2, ])
#' # Partial derivative at point 'xd' respect to 'xg[2]'
#' print(grad_x.4[1, 3])
#' # Partial derivative at point 'yd' respect to 'yd[5]'
#' print(grad_x.4[2, 5])
#' # Gradient respect to the covariance matrix
#' grad_sigma.4 <- d.list.4$grad_sigma
#' # Partial derivative respect to sigma(3, 5) at 
#' # point 'yd'
#' print(grad_sigma.4[3, 5, 2])
#' 
#' # Compare analytical gradients from the previous example with
#' # their numeric (forward difference) analogues at point 'xd'
#' # given conditioning 'xg'
#' delta <- 1e-6
#' grad_x.num <- rep(NA, 5)
#' grad_sigma.num <- matrix(NA, nrow = 5, ncol = 5)
#' for (i in 1:5)
#' {
#'   x.delta <- x
#'   x.delta[i] <- x[i] + delta
#'   d.list.delta <- dmnorm(x = x.delta, mean = mean, sigma = sigma,
#'                          grad_x = TRUE, grad_sigma = TRUE,
#'                          given_ind = given_ind, log = TRUE)
#'   grad_x.num[i] <- (d.list.delta$den - d.list.4$den[1]) / delta
#'    for(j in 1:5)
#'    {
#'      sigma.delta <- sigma
#'      sigma.delta[i, j] <- sigma[i, j] + delta 
#'      sigma.delta[j, i] <- sigma[j, i] + delta 
#'      d.list.delta <- dmnorm(x = x, mean = mean, sigma = sigma.delta,
#'                             grad_x = TRUE, grad_sigma = TRUE,
#'                             given_ind = given_ind, log = TRUE)
#'      grad_sigma.num[i, j] <- (d.list.delta$den - d.list.4$den[1]) / delta
#'    }
#' }
#' # Comparison of gradients respect to the argument
#' h.x <- cbind(analytical = grad_x.4[1, ], numeric = grad_x.num)
#' rownames(h.x) <- c("xg[1]", "xd[1]", "xg[2]", "xd[3]", "xd[4]")
#' print(h.x)
#' # Comparison of gradients respect to the covariance matrix
#' h.sigma <- list(analytical = grad_sigma.4[, , 1], numeric = grad_sigma.num)
#' print(h.sigma)
