#' @details Consider notations from the Details sections of 
#' \code{\link[mnorm]{cmnorm}} and \code{\link[mnorm]{dmnorm}}. 
#' The function calculates probabilities of the form:
#' \deqn{P\left(x^{(l)}\leq X_{I_{d}}\leq 
#' x^{(u)}|X_{I_{g}}=x^{(g)}\right)}
#' where \eqn{x^{(l)}} and \eqn{x^{(u)}} are lower and upper integration
#' limits respectively i.e. \code{lower} and 
#' \code{upper} correspondingly. Also \eqn{x^{(g)}} represents \code{given_x}.
#' Note that \code{lower} and \code{upper} should be matrices of the same size.
#' Also \code{given_x} should have the same number of rows as \code{lower}
#' and \code{upper}.
#'  
#' To calculate bivariate probabilities the function applies the method 
#' described in (REFERENCE). In contrast to the classical implementation of 
#' this method the function applies Gauss-Legendre quadrature with 30 
#' sample points to approximate integral (1) of (REFERENCE). Classical
#' implementations of this method use up to 20 points but requires some 
#' additional transformations of (1). During preliminary testing it has been 
#' found that approach with 30 points provides similar accuracy being 
#' slightly faster because of better vectorization capabilities.
#'  
#' For \eqn{m}-variate probabilities, where \eqn{m>2}, the function applies
#' GHK algorithm described in section 4.2 of (REFERENCE). The implementation
#' of GHK is based on deterministic Halton sequence with \code{n_sim} draws
#' and use variable reordering suggested in section 4.1.3 of (REFERENCE).
#' 
#' We are going to provide alternative estimation algorithms during
#' future updates. This methods will be available via \code{method} argument.
#'  
#' The function is optimized to perform much faster when all upper integration 
#' limits \code{upper} are finite while all lower integration limits 
#' \code{lower} are negative infinite. The derivatives could be also calculated
#' much faster when some integration limits are infinite.
#'  
#' For simplicity of notations further let's consider 
#' unconditioned probabilities. Derivatives respect to conditioned components 
#' are similar to those mentioned in Details section 
#' of \code{\link[mnorm]{dmnorm}}. We also provide formulas for \eqn{m \geq 3}.
#' But the function may calculate derivatives for \eqn{m \leq 2} using some
#' simplifications of the formulas mentioned below. The derivation
#' of formulas used by the function could be found in (REFERENCE).
#' 
#' If \code{grad_upper} is \code{TRUE} then function additionally estimates the
#' gradient respect to \code{upper}:
#' 
#' \deqn{
#' \frac{\partial P\left(x^{(l)}\leq X\leq 
#' x^{(u)}\right)}{\partial x^{(u)}_{i}}=
#' P\left(x^{(l)}_{(-i)}\leq X_{(-i)}\leq x^{(u)}_{(-i)}|
#' X_{i}=x^{(u)}_{i}\right)
#' f_{X_{i}}\left(x^{(u)}_{i};\mu_{i},\Sigma_{i,i}\right)
#' }
#'  
#' If \code{grad_upper} is \code{TRUE} then function additionally estimates the
#' gradient respect to \code{lower}:
#'  
#' \deqn{
#' \frac{\partial P\left(x^{(l)}\leq X\leq 
#' x^{(u)}\right)}{\partial x^{(l)}_{i}}=
#' -P\left(x^{(l)}_{(-i)}\leq X_{(-i)}\leq x^{(u)}_{(-i)}|
#' X_{i}=x^{(u)}_{i}\right)
#' f_{X_{i}}\left(x^{(l)}_{i};\mu_{i},\Sigma_{i,i}\right)
#' }
#' 
#' If \code{grad_sigma} is \code{TRUE} then function additionally estimates the
#' gradient respect to \code{sigma}. For \eqn{i\ne j} the function 
#' calculates derivatives respect to the covariances:
#' 
#' \deqn{
#' \frac{\partial P\left(x^{(l)}\leq X\leq 
#' x^{(u)}\right)}{\partial \Sigma_{i, j}}=}
#' \deqn{
#' =P\left(x^{(l)}_{(-(i, j))}\leq X_{(-i, j)}\leq x^{(u)}_{(-(i, j))}|
#' X_{i}=x^{(u)}_{i}, X_{j}=x^{(u)}_{j}\right)
#' f_{X_{i}, X_{j}}\left(x^{(u)}_{i}, x^{(u)}_{j};
#' \mu_{(i,j)},\Sigma_{(i, j),(i, j)}\right) -
#' }
#' 
#' \deqn{
#' -P\left(x^{(l)}_{(-(i, j))}\leq X_{(-i, j)}\leq x^{(u)}_{(-(i, j))}|
#' X_{i}=x^{(l)}_{i}, X_{j}=x^{(u)}_{j}\right)
#' f_{X_{i}, X_{j}}\left(x^{(l)}_{i}, x^{(u)}_{j};
#' \mu_{(i,j)},\Sigma_{(i, j),(i, j)}\right) -
#' }
#' 
#' \deqn{
#' -P\left(x^{(l)}_{(-(i, j))}\leq X_{(-i, j)}\leq x^{(u)}_{(-(i, j))}|
#' X_{i}=x^{(u)}_{i}, X_{j}=x^{(l)}_{j}\right)
#' f_{X_{i}, X_{j}}\left(x^{(u)}_{i}, x^{(l)}_{j};
#' \mu_{(i,j)},\Sigma_{(i, j),(i, j)}\right) +
#' }
#' 
#' \deqn{
#' +P\left(x^{(l)}_{(-(i, j))}\leq X_{(-i, j)}\leq x^{(u)}_{(-(i, j))}|
#' X_{i}=x^{(l)}_{i}, X_{j}=x^{(l)}_{j}\right)
#' f_{X_{i}, X_{j}}\left(x^{(l)}_{i}, x^{(l)}_{j};
#' \mu_{(i,j)},\Sigma_{(i, j),(i, j)}\right)
#' }
#' 
#' Note that if some of integration limits are infinite then some elements
#' of this equation converge to zero which highly simplifies the calculations.
#' 
#' Derivatives respect to variances are calculated using derivatives
#' respect to covariances and integration limits:
#' 
#' \deqn{
#' \frac{\partial P\left(x^{(l)}\leq X\leq 
#' x^{(u)}\right)}{\partial \Sigma_{i, i}}=
#' }
#' \deqn{
#' -\frac{\partial P\left(x^{(l)}\leq X\leq 
#' x^{(u)}\right)}{\partial x^{(l)}_{i}} \frac{x^{(l)}_{i}}{2\Sigma_{i, i}}
#' -\frac{\partial P\left(x^{(l)}\leq X\leq 
#' x^{(u)}\right)}{\partial x^{(u)}_{i}} \frac{x^{(u)}_{i}}{2\Sigma_{i, i}}-
#' }
#' \deqn{
#' -\sum\limits_{j\ne i}\frac{\partial P\left(x^{(l)}\leq X\leq 
#' x^{(u)}\right)}{\partial \Sigma_{i, j}}
#' \frac{\Sigma_{i, j}}{2\Sigma_{j, j}}
#' }
#' 
#' If \code{grad_given} is \code{TRUE} then function additionally estimates the
#' gradient respect to \code{given_x} using formulas similar to those
#' described in Details section of \code{\link[mnorm]{dmnorm}}.
#' 
