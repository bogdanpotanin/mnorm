#' @param given_x numeric vector which \code{i}-th element corresponds to
#' the given value of the \code{given_ind[i]}-th element (component) of 
#' multivariate normal vector. If \code{given_x} is numeric matrix then it's 
#' rows are such vectors of given values.
