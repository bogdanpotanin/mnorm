#' @param grad_given logical; if \code{TRUE} then the vector of partial 
#' derivatives of the density function will be calculated respect to each
#' element of \code{given_x}. If \code{given_x} is a matrix then gradients 
#' will be estimated for each row of \code{given_x}.
