#' @details Consider notations from the Details section of 
#' \code{\link[mnorm]{cmnorm}}. The function calculates density 
#' \eqn{f(x^{(d)}|x^{(g)})} of conditioned multivariate normal vector 
#' \eqn{X_{I_{d}} | X_{I_{g}} = x^{(g)}}. Where \eqn{x^{(d)}} is a subvector of
#' \eqn{x} associated with \eqn{X_{I_{d}}} i.e. unconditioned components.
#' Therefore \code{x[given_ind]} represents \eqn{x^{(g)}} while
#' \code{x[-given_ind]} is \eqn{x^{(d)}}.
#' 
#' If \code{grad_x} is \code{TRUE} then function additionally estimates the
#' gradient respect to both unconditioned and conditioned components:
#' \deqn{\nabla f(x^{(d)}|x^{(g)})=
#' \left(\frac{\partial f(x^{(d)}|x^{(g)})}{\partial x_{1}}
#' ,..., 
#' \frac{\partial f(x^{(d)}|x^{(g)})}{\partial x_{m}}\right),}
#' where each \eqn{x_{i}} belongs either to \eqn{x^{(d)}} or \eqn{x^{(g)}}
#' depending on whether \eqn{i\in I_{d}} or \eqn{i\in I_{g}} correspondingly.
#' In particular subgradients of density function respect to \eqn{x^{(d)}} 
#' and \eqn{x^{(g)}} are of the form:
#' \deqn{\nabla_{x^{(d)}}\ln f(x^{(d)}|x^{(g)}) =
#' -\left(x^{(d)}-\mu_{c}\right)\Sigma_{c}^{-1}}
#' \deqn{\nabla_{x^{(g)}}\ln f(x^{(d)}|x^{(g)}) =
#' \nabla_{x^{(d)}}f(x^{(d)}|x^{(g)})\Sigma_{d,g}\Sigma_{g,g}^{-1}}
#' 
#' If \code{grad_sigma} is \code{TRUE} then function additionally estimates
#' the gradient respect to the elements of covariance matrix \eqn{\Sigma}.
#' For \eqn{i\in I_{d}} and \eqn{j\in I_{g}} the function calculates:
#' \deqn{
#' \frac{\partial \ln f(x^{(d)}|x^{(g)})}{\partial \Sigma_{i, j}} = 
#' \frac{\partial \ln f(x^{(d)}|x^{(g)})}{\partial x_{i}} \times 
#' \frac{\partial \ln f(x^{(d)}|x^{(g)})}{\partial x_{j}} \times
#' \Sigma_{c,(i, j)}^{-1} / \left(1 + I(i=j)\right),
#' }
#' where \eqn{I(i=j)} is an indicator function which equals \eqn{1} when
#' the condition \eqn{i=j} is satisfied and \eqn{0} otherwise.
#' 
#' For \eqn{i\in I_{d}} and \eqn{j\in I_{g}} the following formula is used:
#' \deqn{
#' \frac{\partial \ln f(x^{(d)}|x^{(g)})}{\partial \Sigma_{i, j}} = 
#' -\frac{\partial \ln f(x^{(d)}|x^{(g)})}{\partial x_{i}} \times 
#' \left(\left(x^{(g)}-\mu_{g}\right)\Sigma_{g,g}^{-1}\right)_{q_{g}(j)}-
#' }\deqn{
#' -\sum\limits_{k=1}^{n_{d}}(1+I(q_{d}(i)=k))\times
#' (\Sigma_{d,g}\Sigma_{g,g}^{-1})_{k,q_{g}(j)}\times
#' \frac{\partial \ln f(x^{(d)}|x^{(g)})}{\partial \Sigma_{i, q^{-1}_{d}(k)}},
#' }
#' where \eqn{q_{g}(j)=\sum\limits_{k=1}^{m} I\left(I_{g,k} \leq j\right)}
#' and \eqn{q_{d}(i)=\sum\limits_{k=1}^{m} I\left(I_{d,k} \leq i\right)}
#' represent the order of the \eqn{i}-th and \eqn{j}-th elements 
#' in \eqn{I_{g}} and \eqn{I_{g}} correspondingly i.e. 
#' \eqn{x_{i}=x^{(d)}_{q_{d}(i)}=x_{I_{d, q_{d}(i)}}} and 
#' \eqn{x_{j}=x^{(g)}_{q_{g}(j)}=x_{I_{g, q_{g}(j)}}}.
#' Note that \eqn{q_{g}(j)^{-1}} and \eqn{q_{d}(i)^{-1}} are inverse functions.
#' Number of conditioned and unconditioned components are denoted by
#' \eqn{n_{g}=\sum\limits_{k=1}^{m}I(k\in I_{g})} and 
#' \eqn{n_{d}=\sum\limits_{k=1}^{m}I(k\in I_{d})} respectively.
#' For the case \eqn{i\in I_{g}} and \eqn{j\in I_{d}} the formula is similar.
#' 
#' For \eqn{i\in I_{g}} and \eqn{j\in I_{g}} the following formula is used:
#' \deqn{
#' \frac{\partial \ln f(x^{(d)}|x^{(g)})}{\partial \Sigma_{i, j}} = 
#' -\nabla_{x^{(d)}}\ln f(x^{(d)}|x^{(g)})\times
#' \left(x^{(g)}\times(\Sigma_{d,g} \times \Sigma_{g,g}^{-1} \times I_{g}^{*} \times 
#' \Sigma_{g,g}^{-1})^{T}\right)^T -
#' }\deqn{
#' -\sum\limits_{k_{1}=1}^{n_{d}}\sum\limits_{k_{2}=1}^{n_{d}}
#' \frac{\partial \ln f(x^{(d)}|x^{(g)})}
#' {\partial \Sigma_{q_{d}(k_{1})^{-1}, q_{d}(k_{2})^{-1}}}
#' \left(\Sigma_{d,g} \times \Sigma_{g,g}^{-1} \times I_{g}^{*} \times 
#' \Sigma_{g,g}^{-1}\times\Sigma_{d,g}^T\right)_{q_{d}(k_{1})^{-1}, 
#' q_{d}(k_{2})^{-1},}
#' }
#' where \eqn{I_{g}^{*}} is a square \eqn{n_{g}}-dimensional matrix of 
#' zeros except \eqn{I_{g,(i,j)}^{*}=I_{g,(j,i)}^{*}=1}.
#' 
#' Argument \code{given_ind} represents \eqn{I_{g}} and it should not 
#' contain any duplicates. The order of \code{given_ind} elements
#' does not matter so it has no impact on the output.
