#' @param is_validation logical value indicating whether input 
#' arguments should be validated.  Set it to \code{FALSE} to get
#' performance boost (default value is \code{TRUE}).
