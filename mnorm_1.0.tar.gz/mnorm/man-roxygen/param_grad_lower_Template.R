#' @param grad_lower logical; if \code{TRUE} then the vector of partial 
#' derivatives of the probability will be calculated respect to each
#' element of \code{lower}. If \code{lower} is a matrix then gradients will be
#' estimated for each row of \code{lower}.
