#' @param is_names logical value indicating whether output 
#' values should have row and column names. Set it to \code{FALSE} to get
#' performance boost (default value is \code{TRUE}).
