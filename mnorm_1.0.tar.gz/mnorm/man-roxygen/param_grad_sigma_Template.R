#' @param grad_sigma logical; if \code{TRUE} then the vector of partial
#' derivatives (gradient) of the density function will be calculated respect 
#' to each element of \code{sigma}. If \code{x} is a matrix then gradients 
#' will be estimated for each row of \code{x}.
