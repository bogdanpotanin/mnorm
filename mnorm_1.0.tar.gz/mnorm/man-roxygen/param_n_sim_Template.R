#' @param n_sim positive integer representing the number of draws from Halton 
#' sequence in GHK algorithm. More draws provide more accurate results by the 
#' cost of additional computational burden.
