#' @param grad_sigma logical; if \code{TRUE} then the vector of partial
#' derivatives (gradient) of the probability will be calculated respect 
#' to each element of \code{sigma}. If \code{lower} and \code{upper} are
#' matrices then gradients will be estimated for each row of these matrices.
