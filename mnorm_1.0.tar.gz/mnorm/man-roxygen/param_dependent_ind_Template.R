#' @param dependent_ind numeric vector representing indexes of unconditional
#' elements (components) of multivariate normal vector.
