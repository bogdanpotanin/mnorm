#' @param n_cores positive integer representing the number of CPU cores
#' used for parallel computing. Currently it is not recommended to set
#' \code{n_cores > 1} if \code{nrow(lower) < 100000}.
