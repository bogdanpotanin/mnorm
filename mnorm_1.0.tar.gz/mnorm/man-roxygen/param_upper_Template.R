#' @param upper numeric vector representing upper integration limits.
#' If \code{upper} is a matrix then each row determines new limits. Positive
#' infinite values are allowed while negative infinite values are prohibited.
