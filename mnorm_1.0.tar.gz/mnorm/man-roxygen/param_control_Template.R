#' @param control a list of control parameters. See Details.
