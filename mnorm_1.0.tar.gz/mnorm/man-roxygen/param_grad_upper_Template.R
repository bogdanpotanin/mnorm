#' @param grad_upper logical; if \code{TRUE} then the vector of partial 
#' derivatives of the probability will be calculated respect to each
#' element of \code{upper}. If \code{upper} is a matrix then gradients will be
#' estimated for each row of \code{upper}.
