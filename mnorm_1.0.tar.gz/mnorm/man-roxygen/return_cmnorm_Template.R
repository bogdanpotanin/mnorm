#' @return This function returns an object of class "mnorm_cmnorm".\cr \cr
#' An object of class "mnorm_cmnorm" is a list containing the 
#' following components:
#' \itemize{
#' \item \code{mean} - conditional mean.
#' \item \code{sigma} - conditional covariance matrix.
#' \item \code{sigma_d} - covariance matrix of unconditioned elements.
#' \item \code{sigma_g} - covariance matrix of conditioned elements.
#' \item \code{sigma_dg} - matrix of covariances between unconditioned
#' and conditioned elements.
#' \item \code{s12s22} - equals to the matrix product of \code{sigma_dg}
#' and \code{solve(sigma_g)}.
#' }
#' 
#' Note that \code{mean} corresponds to \eqn{\mu_{c}} while \code{sigma}
#' represents \eqn{\Sigma_{c}}. Moreover \code{sigma_d} is 
#' \eqn{\Sigma_{I_{d}, I_{d}}}, \code{sigma_g} is \eqn{\Sigma_{I_{g}, I_{g}}} 
#' and \code{sigma_dg} is \eqn{\Sigma_{I_{d}, I_{g}}}.
#' 
#' Since \eqn{\Sigma_{c}} do not depend on
#' \eqn{X^{(g)}} the output \code{sigma} does not depend on \code{given_x}.
#' In particular output \code{sigma} remains the same independent of whether 
#' \code{given_x} is a matrix or vector. Oppositely if \code{given_x} is
#' a matrix then output \code{mean} is a matrix which rows correspond
#' to conditional means associated with given values provided by corresponding
#' rows of \code{given_x}.
#' 
#' The order of elements of output \code{mean} and output \code{sigma} depends 
#' on the order of \code{dependet_ind} elements that is ascending by default.
#' The order of \code{given_ind} elements does not matter. But, please, check 
#' that the order of \code{given_ind} match the order of given values i.e. 
#' the order of \code{given_x} columns.
