#' @param given_ind numeric vector representing indexes of multivariate
#' normal vector which are conditioned at values given by 
#' \code{given_x} argument.
