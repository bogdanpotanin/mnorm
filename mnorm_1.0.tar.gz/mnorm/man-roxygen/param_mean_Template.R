#' @param mean numeric vector representing expectation of multivariate
#' normal vector (distribution).
