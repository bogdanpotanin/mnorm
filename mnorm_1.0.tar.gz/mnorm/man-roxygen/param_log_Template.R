#' @param log logical; if \code{TRUE} then probabilities (or densities) p are 
#' given as log(p) and derivatives will be given respect to log(p).
