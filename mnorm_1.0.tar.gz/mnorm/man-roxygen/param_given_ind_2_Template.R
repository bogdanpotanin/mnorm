#' @param given_ind numeric vector representing indexes of multivariate
#' normal vector which are conditioned at values of \code{x} with corresponding 
#' indexes i.e. \code{x[given_x]} or \code{x[, given_x]} if 
#' \code{x} is a matrix.
