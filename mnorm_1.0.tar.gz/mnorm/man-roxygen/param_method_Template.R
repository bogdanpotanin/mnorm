#' @param method string representing the method to be used to calculate
#' multivariate normal probabilities. Currently \code{"default"} is the
#' only available option. See Details section below.
