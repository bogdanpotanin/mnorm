#' @return This function returns an object of class "mnorm_dmnorm".\cr \cr
#' An object of class "mnorm_dmnorm" is a list containing the 
#' following components:
#' \itemize{
#' \item \code{den} - density function value at \code{x}.
#' \item \code{grad_x} - gradient of density respect to \code{x} if 
#' \code{grad_x} or \code{grad_sigma} input argument is set to \code{TRUE}. 
#' \item \code{grad_sigma} - gradient respect to the elements of \code{sigma}
#' if \code{grad_sigma} input argument is set to \code{TRUE}.
#' }
#' 
#' If \code{log} is \code{TRUE} then \code{den} is a log-density
#' so output \code{grad_x} and \code{grad_sigma} are calculated respect 
#' to the log-density.
#' 
#' Output \code{grad_x} is a Jacobian matrix which rows are gradients of 
#' the density function calculated for each row of \code{x}. Therefore
#' \code{grad_x[i, j]} is a derivative of the density function respect to the
#' \code{j}-th argument at point \code{x[i, ]}.
#' 
#' Output \code{grad_sigma} is a 3D array such that \code{grad_sigma[i, j, k]} 
#' is a partial derivative of the density function respect to the 
#' \code{sigma[i, j]} estimated for the observation \code{x[k, ]}.
#' 
