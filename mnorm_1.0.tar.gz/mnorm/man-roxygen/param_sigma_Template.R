#' @param sigma positively defined numeric matrix representing covariance
#' matrix of multivariate normal vector (distribution).
