#' @param x numeric vector representing the point at which density
#' should be calculated. If \code{x} is a matrix then each row determines
#' a new point.
