#' @examples
#' # Consider multivariate normal vector:
#' # X = (X1, X2, X3, X4, X5) ~ N(mean, sigma)
#' 
#' # Prepare multivariate normal vector parameters
#'   # expected value
#' mean <- c(-2, -1, 0, 1, 2)
#' n_dim <- length(mean)
#'   # correlation matrix
#' cor <- c(   1,  0.1,  0.2,   0.3,  0.4,
#'           0.1,    1, -0.1,  -0.2, -0.3,
#'           0.2, -0.1,    1,   0.3,  0.2,
#'           0.3, -0.2,  0.3,     1, -0.05,
#'           0.4, -0.3,  0.2, -0.05,     1)
#' cor <- matrix(cor, ncol = n_dim, nrow = n_dim, byrow = TRUE)
#'   # covariance matrix
#' sd_mat <- diag(c(1, 1.5, 2, 2.5, 3))
#' sigma <- sd_mat %*% cor %*% t(sd_mat)
#'
#' # Estimate parameters of conditional distribution i.e.
#' # when the first and the third components of X are conditioned:
#' # (X2, X4, X5 | X1 = -1, X3 = 1)
#' given_ind <- c(1, 3)
#' given_x <- c(-1, 1)
#' par <- cmnorm(mean = mean, sigma = sigma,
#'               given_ind = given_ind,
#'               given_x = given_x)
#'   # E(X2, X4, X5 | X1 = -1, X3 = 1)
#' par$mean
#'   # Cov(X2, X4, X5 | X1 = -1, X3 = 1)
#' par$sigma
#' 
#' # Additionally calculate E(X2, X4, X5 | X1 = 2, X3 = 3)
#' given_x_mat <- rbind(given_x, c(2, 3))
#' par1 <- cmnorm(mean = mean, sigma = sigma,
#'                given_ind = given_ind,
#'                given_x = given_x_mat)
#' par1$mean
#' 
#' # Duplicates and omitted indexes are allowed for dependent_ind
#' # For given_ind duplicates are not allowed
#' # Let's calculate conditional parameters for (X5, X2, X5 | X1 = -1, X3 = 1):
#' dependent_ind <- c(5, 2, 5)
#' par2 <- cmnorm(mean = mean, sigma = sigma,
#'                given_ind = given_ind,
#'                given_x = given_x,
#'                dependent_ind = dependent_ind)
#'   # E(X5, X2, X5 | X1 = -1, X3 = 1)
#' par2$mean
#'   # Cov(X5, X2, X5 | X1 = -1, X3 = 1)
#' par2$sigma
