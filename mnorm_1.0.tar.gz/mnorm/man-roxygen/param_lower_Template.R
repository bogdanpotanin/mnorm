#' @param lower numeric vector representing lower integration limits.
#' If \code{lower} is a matrix then each row determines new limits. Negative
#' infinite values are allowed while positive infinite values are prohibited.
