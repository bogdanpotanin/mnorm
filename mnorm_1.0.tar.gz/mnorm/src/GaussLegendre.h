#ifndef mnorm_GaussLegendre_H
#define mnorm_GaussLegendre_H

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace RcppArmadillo;

NumericMatrix GaussQuadrature(int n);

#endif
