// [[Rcpp::depends(hpa)]]
#include <RcppArmadillo.h>
#include <omp.h>
using namespace Rcpp;

// // Multiply row vector by triangular matrix
// // [[Rcpp::export(rng = false)]]
// arma::vec arma_rowvec_by_upper_triangular(arma::rowvec const &vec, 
//                                           arma::mat const &mat)
//   {
//     int const n_dim = mat.n_cols;
//     arma::vec vec_out = arma::vec(n_dim);
//     
//     for(int i = 0; i < n_dim; i ++)
//     {
//       double sum_row = 0;
//       for(int j = 0; j <= i; j++)
//       {
//         sum_row += vec[j] * mat.at(j, i);
//       }
//       vec_out[i] = sum_row;
//   }
// }
// 
// // Get submatrix of NumericMatrix by LogicalVector
// // [[Rcpp::export(rng = false)]]
// NumericMatrix submat_NM(const NumericMatrix x, const LogicalVector ind, 
//                         int n = 0, int m = 0)
// {
//   if (n <= 0)
//   {
//     int n = x.size();
//   }
//   if (m <= 0)
//   {
//     int m = sum(ind);
//   }
//   NumericMatrix x_new(m);
//   int counter = 0;
//   for (int i = 0; i < n; i++)
//   {
//     if (ind[i])
//     {
//       x_new(_, counter) = x(_, i);
//       counter++;
//     }
//   }
//   return(x_new);
// }

// // Get submatrix of NumericMatrix by LogicalVector
// // [[Rcpp::export(rng = false)]]
// NumericMatrix cols_NM(const NumericMatrix x, 
//                       const NumericVector ind,
//                       const bool exclude = false)
// {
//   int n_ind = ind.size();
//   NumericVector ind_new = ind;
//   if (exclude)
//   {
//     const int n_col = x.ncol();
//     int n_ind_new = n_col - n_ind;
//     for (int i = 0; i < m; i++)
//     {
//       ind = 0;
//     }
//   }
//   else
//   {
//     ind_new = ind;
//     n_ind_new = n_ind;
//   }
//   for (int i = 0; i < n_ind_new; i++)
//   {
//     y(_, i) = x(_, ind_new[i]);
//   }
//   return(y);
// }
// 
