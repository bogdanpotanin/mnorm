#ifndef mnorm_linal_H
#define mnorm_linal_H

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace RcppArmadillo;

arma::vec arma_rowvec_by_upper_triangular(arma::rowvec const &vec, 
                                          arma::mat const &mat);

#endif
