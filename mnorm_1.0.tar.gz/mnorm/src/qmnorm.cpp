// [[Rcpp::depends(hpa)]]
#include <RcppArmadillo.h>
#include <omp.h>
#include "cmnorm.h"
#include "dmnorm.h"
#include "qmnorm.h"
using namespace Rcpp;

// [[Rcpp::plugins(openmp)]]

// --------------------------------------
// --------------------------------------
// --------------------------------------

// [[Rcpp::export(rng = false)]]
arma::vec qnormFast(arma::vec const &p, const int n_cores = 1)
{
  // Multiple cores
  omp_set_num_threads(n_cores);
  
  // The number of quantiles to calculate
  const int n = p.size();
  
  // The vector of quantiles (output)
  arma::vec val(n);
  
  // Voutier, P.M. (2010). A New Approximation to the Normal 
  // Distribution Quantile Function. arXiv: Computation.
    
  // Constants for the central region
  const double a0 = 0.195740115269792;
  const double a1 = -0.652871358365296;
  const double a2 = 1.246899760652504;
  const double b0 = 0.155331081623168;
  const double b1 = -0.839293158122257;
    
  // Constants for the tails
  const double c0 = 16.682320830719986527;
  const double c1 = 4.120411523939115059;
  const double c2 = 0.029814187308200211;
  const double c3 = -1.000182518730158122;
  const double d0 = 7.173787663925508066;
  const double d1 = 8.759693508958633869;
  
  double r;
  double q;
  for (int i = 0; i < n; i++)
  {
    if ((0.025 <= p.at(i)) & (p.at(i) <= 0.975))
    {
      q = p.at(i) - 0.5;
      r = std::pow(q, 2.0);
      val.at(i) = q * (a2 + (a1 * r + a0) / 
                      (std::pow(r, 2.0) + b1 * r + b0));
    }
    else
    {
      if (p.at(i) < 0.5)
      {
        r = sqrt(log(1 / (std::pow(p.at(i), 2.0))));
      }
      else
      {
        r = sqrt(log(1 / (std::pow(1 - p.at(i), 2.0))));
      }
      val.at(i) = c3 * r + c2 + 
                  (c1 * r + c0) / (std::pow(r, 2.0) + d1 * r + d0);
      if (p.at(i) > 0.5)
      {
        val.at(i) = -val.at(i);
      }
    }
  }
  
  return(val);
}
