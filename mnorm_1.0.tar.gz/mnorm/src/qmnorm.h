#ifndef mnorm_qmnorm_H
#define mnorm_qmnorm_H

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace RcppArmadillo;

arma::vec qnormFast(arma::vec const &p, const int n_cores);

#endif
